<?php
if (!isset($mysqli)) {
    include '../function/function.php';
}
include 'sidebar.php';
include 'header.php';
$mysqli = connect();
$user = $_SESSION['user'];


?>
<html>
    <head>
        <link rel="stylesheet" href="">
    </head>
</html>