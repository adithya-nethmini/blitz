<?php
if (!isset($mysqli)) {
    include '../function/function.php';
}
include 'sidebar.php';
include 'header.php';
$mysqli = connect();
$user = $_SESSION['user'];


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Blitz</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../views/css/view.css">
    <link rel="stylesheet" href="../../views/css/header.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://kit.fontawesome.com/21e5980a06.js" crossorigin="anonymous"></script>
</head>
<section>
    <div class="profile-container">

        <div class="page">

            <div class="page-content">
                <div class="heading">
                    
                    <h1>View Project</h1>
                </div>



                <?php
                $id = $_GET['id'];
                $qry = "SELECT name,description,start_date,end_date,status,manager_id,user_ids from project_list WHERE id=$id";
                if (mysqli_query($mysqli, $qry)) :
                    $row = mysqli_fetch_assoc(mysqli_query($mysqli, $qry));
                    $name = $row['name'];
                    $description = $row['description'];
                    $start_date = $row['start_date'];
                    $end_date = $row['end_date'];
                    $status = $row['status'];
                    $manager_id = $row['manager_id'];
                    $user_ids = $row['user_ids'];
                ?>


                    <div class="container">
                        <div class="up-outer-container">
                            <div class="up-inner-left">
                                <div>
                                    <h3>Project Name</h3>
                                    <?php echo $name; ?>
                                </div>
                                <div>
                                    <h3>Description</h3>
                                    <?php echo $description; ?>
                                </div>
                            </div>
                            <div class="up-inner-right">
                                <div>
                                    <h3>Start Date</h3>
                                    <?php echo $start_date ?>
                                </div>
                                <div>
                                    <h3>End Date</h3>
                                    <?php echo $end_date ?>
                                </div>
                                <div>
                                    <h3>Status</h3>
                                    <?php
                                    if ($status == '0') :
                                        $status = 'started'; ?>
                                        <span class="started"><?php echo $status; ?></span>
                                    <?php
                                    elseif ($status == 3) :
                                        $status = 'On-Progress'; ?>
                                        <span class="ongoing"><?php echo $status; ?></span>
                                    <?php
                                    elseif ($status == 5) :
                                        $status = 'Done'; ?>
                                        <span class="done"><?php echo $status; ?></span>
                                    <?php
                                    else :
                                    ?>
                                        <span>No data</span>
                                    <?php endif; ?>

                                </div>
                                <div>
                                    <h3>Project Manager</h3>
                                    <?php echo $manager_id ?>
                                </div>
                                <div>
                                    <h3>Team Members</h3>
                                    <?php echo $user_ids; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <br>

            </div>
            <div class="page">

                <div class="page-content1">
                    <!-- <div class="leave-container2"></div> -->
                    <div class="leave-container2">

                        <div class="header">
                            <div class="topic1">
                                <h2>Task List</h2>
                            </div>



                        </div>

                        <div class="all-tasks">

                            <table id="table" class="task-tbl">

                        </div>
                        <tr class="table-header">
                            <th>Task</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        <?php
                        // $qry = "SELECT task,description,status from task_list WHERE project_id=$id";
                        $user = $_SESSION['user'];
                        $qry = "SELECT * FROM task_list WHERE project_id=$id AND FIND_IN_SET('$user', emp_id) > 0";
                        $result = $mysqli->query($qry);

                        if ($result->num_rows > 0) :
                            while ($row = $result->fetch_assoc()) :
                                $id = $row['id'];
                                echo '
                <tr>
                    <td>' . $row['task'] . '</td>';
                                if ($row['status'] == 0) {
                                    echo '<td><span class="started"> Started</span></td>';
                                } elseif ($row['status'] == 3) {
                                    echo '<td><span class="ongoing"> On-Progress</span></td>';
                                } elseif ($row['status'] == 5) {
                                    echo '<td><span class="done"> Done</span></td>';
                                }
                                echo ' <td>
                                    <div class="">
                                        <a href="task_view.php?id=' . $id . '"><button class="view-btn">View</button></a>
                                    </div>
                                </td>';
                        ?>

                    </div>
            <?php

                            endwhile;
                        else :
                            echo mysqli_error($mysqli);

                        endif;
                        //        
            ?>

            </tr>
            </table>
                </div>
            </div><br>
        </div>
    </div>
    </div>